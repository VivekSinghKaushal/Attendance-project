import 'package:get/get.dart';
import 'package:vivekfinaltest/core/route_constant.dart';
import 'package:vivekfinaltest/feature/create_account/binding/create_bind.dart';
import 'package:vivekfinaltest/feature/create_account/view/create_view.dart';
import 'package:vivekfinaltest/feature/login/binding/login_binding.dart';
import 'package:vivekfinaltest/feature/login/view/login_view.dart';
import 'package:vivekfinaltest/feature/onboarding/binding/onboarding_binding.dart';
import 'package:vivekfinaltest/feature/onboarding/view/onboarding_view.dart';
import 'package:vivekfinaltest/feature/screen/binding/screen_binding.dart';
import 'package:vivekfinaltest/feature/screen/view/screen)view.dart';
import 'package:vivekfinaltest/feature/slpash/binding/splash_binding.dart';
import 'package:vivekfinaltest/feature/slpash/view/splash_view.dart';
import 'package:vivekfinaltest/feature/welcome/binding/wel_binding.dart';

import 'package:vivekfinaltest/feature/welcome/view/wel_view.dart';

List<GetPage> getPages = [
  GetPage(name: RouteConstant.splash,
    page:()=>SplashScreen(),
    binding:SplashBinding(),
  ),

  GetPage(name: RouteConstant.onboarding,
    page:()=>OnboardingPage(),
    binding:OnboardingBinding(),
  ),

  GetPage(name: RouteConstant.login,
    page:()=>loginPage(),
    binding:Loginbinding(),
  ),


  GetPage(name: RouteConstant.welcome,
    page:()=>welcomePage(),
   binding:welcomebinding(),
  ),

  GetPage(name: RouteConstant.createaccount,
    page:()=>CreateView(),
    binding:CreateBinding(),
  ),

  GetPage(name: RouteConstant.screen,
    page:()=>ScreenView(),
    binding:ScreenBinding(),
  ),


];