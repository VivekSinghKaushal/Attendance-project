import 'package:get/get.dart';

RxBool autologin=false.obs;