class RouteConstant{
  static const String splash = '/splash_view.dart';
  static const String onboarding = '/onboarding_view.dart';
  static const String login = '/login_view.dart';
  static const String welcome = '/wel_view.dart';
  static const String createaccount = '/lib/feature/create_account/view';
  static const String screen = '/screen)view.dart';
}