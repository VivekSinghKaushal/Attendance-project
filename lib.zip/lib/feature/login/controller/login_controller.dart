import 'package:flutter/material.dart';
import 'package:get/get.dart';

// class LoginController extends GetxController{
//   final nameController = TextEditingController();
//   final passController = TextEditingController();
//   final loginFormKey = GlobalKey<FormState>();
//
//   validator(){
//     if(loginFormKey.currentState!.validate()){
//
//     }
//   }
// }


class LoginController extends GetxController{
  bool _obscureText= false;
  eye(){
    _obscureText=!_obscureText;
  }


}