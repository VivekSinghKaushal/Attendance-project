import 'package:get/get.dart';

class WelcomeController extends GetxController{

  }
