
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CreateController extends GetxController{
  late TextEditingController userNameController = new TextEditingController();
  late TextEditingController userPasswordController = new TextEditingController();
  GlobalKey<FormState> loginFormKey = new GlobalKey<FormState>();
  validateForm(){
    var isValide = loginFormKey.currentState?.validate();

  }

}
