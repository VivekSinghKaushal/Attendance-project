
import 'package:get/get.dart';
import 'package:vivekfinaltest/feature/create_account/controller/ceate_conn.dart';



class CreateBinding extends Bindings{
  @override
  void dependencies() {
    // TODO: implement dependencies
    Get.put(CreateController());
  }

}