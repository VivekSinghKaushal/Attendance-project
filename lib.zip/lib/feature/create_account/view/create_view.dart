








import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:get/get.dart';
import 'package:vivekfinaltest/core/route_constant.dart';
import 'package:vivekfinaltest/feature/create_account/controller/ceate_conn.dart';



class CreateView extends GetView<CreateController>{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text(""),
      ),
      body:  SingleChildScrollView(
        child: Form(
          key:controller.loginFormKey,

          child: Container(

            width: Get.width,
            height: Get.height,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Colors.white10,
              boxShadow: [
                BoxShadow(
                  color: Color.fromARGB(255, 201, 204, 202),
                  offset: const Offset(
                    5.0,
                    5.0,
                  ),
                  blurRadius: 10.0,
                  spreadRadius: 2.0,
                ), //BoxShadow
                BoxShadow(
                  color: Colors.white,
                  offset: const Offset(0.0, 0.0),
                  blurRadius: 0.0,
                  spreadRadius: 0.0,
                ),
                //BoxShadow
              ],
            ),
            child: Container(
              margin: EdgeInsets.all(10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [

                  Column(
                    //form starts

                    children: [
                      Container(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,


                            children: [
                              Text(''),
                              Text("CREATE ACCOUNT",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold)),
                              Text(''),
                              Text("ENTER YOUR NUMBER TO SAND OTP",style: TextStyle(fontSize: 22,fontWeight: FontWeight.bold)),
                              Text(""),

                            ],
                          )
                      ),
                      SizedBox(height:80,),
                      Container(
                        margin: EdgeInsets.only(bottom: 18),
                        child:TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(
                            labelText: ' Enter Phone Number',
                            border:OutlineInputBorder(),

                          ),

                          // controller: controller.userNameController,

                          validator:(value){

                            if(value == null || value.isEmpty){
                              return 'Please enter email';
                            }
                            return null;
                          } ,
                        ),
                      ),
                      SizedBox(height:50,),

                      Container(
                        height: 60,
                        width: 500,
                        child: ElevatedButton(

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                                child:Text('SAND OTP',
                                  style:TextStyle(
                                    fontWeight: FontWeight.bold,fontSize: 25,

                                  ),
                                ),
                              ),
                            ],
                          ),

                          onPressed: (){

                            controller.validateForm();

                          },
                          style: ButtonStyle(
                            backgroundColor: MaterialStatePropertyAll(Colors.blue),
                            shape:MaterialStatePropertyAll(RoundedRectangleBorder(side: BorderSide(color: Colors.white,width: 1,style: BorderStyle.solid),borderRadius: BorderRadius.circular(50),
                            ),

                            ),


                          ),
                        ),
                      ),
                      SizedBox(height:50,),
                      Row(mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text("----------------OR-----------------",style:TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),
                          // TextButton(onPressed:(){} , child:Text("SIGN UP",style:TextStyle(fontSize: 25,fontWeight: FontWeight.bold),))
                        ],
                      ),
                      SizedBox(height:50,),
                      Container(
                        height: 60,
                        width: 500,
                        child: ElevatedButton(

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: EdgeInsets.fromLTRB(0, 12, 0, 12),
                                child:Row(
                                  children: [


                                    Text('SIGNUP WITH GOOGLE',
                                      style:TextStyle(
                                          fontWeight: FontWeight.bold,fontSize: 25,
                                          color: Colors.blue

                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),

                          onPressed: (){
                            // controller.validateForm();
                            Get.toNamed(RouteConstant.screen);

                          },
                          style: ButtonStyle(
                            backgroundColor: MaterialStatePropertyAll(Colors.white),
                            shape:MaterialStatePropertyAll(RoundedRectangleBorder(side: BorderSide(color: Colors.blue,width: 1,style: BorderStyle.solid),borderRadius: BorderRadius.circular(50),
                            ),

                            ),


                          ),
                        ),
                      ),

                    ],
                  ),
                  //for last

                ],
              ),

            ),
          ),
        ),
      ),
    );
  }

}